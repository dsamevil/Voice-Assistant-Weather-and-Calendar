import os
import sys

# Import your existing modules
try:
    import main
    import speech_module
except ImportError as e:
    print(f"Error importing modules: {e}")
    sys.exit(1)

# --- CONFIGURATION ---
INTERNAL_AUDIO_DIR = "test_audio"   # Default internal folder
USER_INPUT_PATH = "user_input"      # Path for user injection (File OR Folder)

# --- MOCKING ---
def mock_speak(text):
    print(f"\n[ASSISTANT OUTPUT]: {text}")

# Patch the functions
main.speak_text = mock_speak
speech_module.speak_text = mock_speak

def process_single_file(file_path):
    """Helper to process one file"""
    print(f"\n>>> Processing file: {os.path.basename(file_path)}")
    user_text = speech_module.transcribe_audio(file_path)
    if user_text:
        print(f"[TRANSCRIPTION]: {user_text}")
        main.handle_command(user_text)
    else:
        print("[ERROR]: Could not transcribe audio.")

# --- RUNNER ---
def run_docker_tests():
    print("--- STARTING DOCKER BATCH MODE ---")
    
    # CHECK: Did the user provide input?
    if os.path.exists(USER_INPUT_PATH):
        print(f"\n--- User Input Detected ({USER_INPUT_PATH}) ---")
        print("Skipping internal test files.\n")
        
        # Case A: User provided a FOLDER (Multiple files)
        if os.path.isdir(USER_INPUT_PATH):
            files = sorted([f for f in os.listdir(USER_INPUT_PATH) if f.lower().endswith(".wav")])
            if not files:
                print("Folder mounted, but no .wav files found inside.")
            for filename in files:
                process_single_file(os.path.join(USER_INPUT_PATH, filename))
                
        # Case B: User provided a SINGLE FILE
        elif os.path.isfile(USER_INPUT_PATH):
             process_single_file(USER_INPUT_PATH)
             
    else:
        # FALLBACK: No user input, run default internal files
        print(f"\n[INFO]: No user input at '/app/{USER_INPUT_PATH}'.")
        print("Running default internal test files...\n")
        
        if os.path.exists(INTERNAL_AUDIO_DIR) and os.path.isdir(INTERNAL_AUDIO_DIR):
            files = sorted([f for f in os.listdir(INTERNAL_AUDIO_DIR) if f.lower().endswith(".wav")])
            for filename in files:
                process_single_file(os.path.join(INTERNAL_AUDIO_DIR, filename))

if __name__ == "__main__":
    run_docker_tests()