import os
import sys

# Import your existing modules
# We wrap this in try/except to handle potential import errors gracefully
try:
    import main
    import speech_module
except ImportError as e:
    print(f"Error importing modules: {e}")
    sys.exit(1)

# --- CONFIGURATION ---
AUDIO_DIR = "test_audio"

# --- MOCKING ---
# We overwrite the speak function so it doesn't try to access speakers
def mock_speak(text):
    print(f"\n[ASSISTANT OUTPUT]: {text}")

# Patch the functions in your modules to use the mock
main.speak_text = mock_speak
speech_module.speak_text = mock_speak

# --- RUNNER ---
def run_docker_tests():
    print("--- STARTING DOCKER BATCH MODE ---")
    
    if not os.path.exists(AUDIO_DIR):
        print(f"Error: Directory '{AUDIO_DIR}' not found.")
        return

    # Get all .wav files and sort them so they run in order
    files = sorted([f for f in os.listdir(AUDIO_DIR) if f.endswith(".wav")])
    
    if not files:
        print("No .wav files found in test_audio/")
        return

    for filename in files:
        file_path = os.path.join(AUDIO_DIR, filename)
        print(f"\n>>> Processing file: {filename}")
        
        # 1. Transcribe the file
        user_text = speech_module.transcribe_audio(file_path)
        
        # 2. Feed text to your main command handler
        if user_text:
            print(f"[TRANSCRIPTION]: {user_text}")
            main.handle_command(user_text)
        else:
            print("[ERROR]: Could not transcribe audio.")

if __name__ == "__main__":
    run_docker_tests()